package cn.nicenan.meeting.mapper;

import cn.nicenan.meeting.model.Selection;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Nannan
 * @since 2019-12-06
 */
public interface SelectionMapper extends BaseMapper<Selection> {

}
