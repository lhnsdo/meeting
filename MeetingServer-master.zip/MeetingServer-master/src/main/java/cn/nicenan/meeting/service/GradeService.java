package cn.nicenan.meeting.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.nicenan.meeting.model.Grade;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Nannan
 * @since 2019-08-18
 */
public interface GradeService extends IService<Grade> {

}
