package cn.nicenan.meeting.mapper;

import cn.nicenan.meeting.model.Grade;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Nannan
 * @since 2019-08-18
 */
public interface GradeMapper extends BaseMapper<Grade> {

}
